"""Forward measurements for inspecting regional hidden-unit inactivity."""
import numpy as np
import torch


def inspect_hidden_activations(model, X, time, near_zero=1e-8):
    """Measure both hidden layers without changing weights or training state.

    Exact zeros and small magnitudes are distinct. A unit zero on all supplied
    rows is only inactive over that dataset, not necessarily throughout training.
    """
    was_training = model.training
    model.eval()
    arrays = {"time": np.asarray(time)}
    summary = {"n_samples": len(time), "near_zero_threshold": near_zero, "layers": {}}
    try:
        with torch.no_grad():
            values = torch.as_tensor(X, dtype=torch.float32)
            for layer, linear_idx in enumerate((0, 2), start=1):
                pre = model.network[linear_idx](values)
                values = model.network[linear_idx + 1](pre)
                pre_array, post = pre.cpu().numpy(), values.cpu().numpy()
                arrays[f"layer_{layer}_pre"] = pre_array
                arrays[f"layer_{layer}_post"] = post
                zeros = post == 0
                summary["layers"][f"layer_{layer}"] = {
                    "pre_nonpositive_fraction": float((pre_array <= 0).mean()),
                    "exact_zero_fraction": float(zeros.mean()),
                    "near_zero_fraction": float((np.abs(post) <= near_zero).mean()),
                    "all_units_zero_row_fraction": float(zeros.all(axis=1).mean()),
                    "units_zero_on_all_rows": np.flatnonzero(zeros.all(axis=0)).tolist(),
                    "zero_fraction_per_unit": zeros.mean(axis=0).tolist(),
                }
            arrays["prediction"] = model.network[4](values).squeeze(-1).cpu().numpy()
            summary["output_bias"] = float(model.network[4].bias.item())
            all_zero = (arrays["layer_2_post"] == 0).all(axis=1)
            summary["last_hidden_all_zero_times"] = arrays["time"][all_zero].tolist()
            summary["prediction_equals_bias_when_last_hidden_zero"] = (
                bool(np.all(arrays["prediction"][all_zero] == summary["output_bias"]))
                if all_zero.any() else None
            )
    finally:
        model.train(was_training)
    return summary, arrays


def plot_activation_diagnostics(arrays, relevance, target, title):
    """Show output, exact-zero hidden fractions, and raw relevance together."""
    import matplotlib.pyplot as plt

    time = arrays["time"]
    fig, axes = plt.subplots(3, 1, figsize=(12, 9), sharex=True)
    axes[0].plot(time, target, color="black", label="Target")
    axes[0].plot(time, arrays["prediction"], label="Prediction")
    axes[0].set_yscale("symlog", linthresh=1)
    axes[0].set_ylabel("Prediction (symlog)")
    for layer in (1, 2):
        axes[1].plot(time, (arrays[f"layer_{layer}_post"] == 0).mean(axis=1),
                     label=f"Hidden layer {layer}")
    axes[1].set_ylabel("Fraction exactly zero")
    axes[1].set_ylim(-0.05, 1.05)
    absolute = np.abs(relevance)
    axes[2].plot(time, absolute.sum(axis=1), label="Total absolute relevance")
    axes[2].plot(time, absolute[:, -1], label="Absolute shortcut relevance")
    axes[2].set_yscale("symlog", linthresh=1e-6)
    axes[2].set_ylabel("Raw relevance (symlog)")
    axes[2].set_xlabel("Time index")
    for ax in axes:
        ax.legend()
    fig.suptitle(title)
    fig.tight_layout()
    return fig
